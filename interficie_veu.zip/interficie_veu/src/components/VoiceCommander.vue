<script setup>
import { ref, watch } from 'vue';
import { useTheme } from 'vuetify'; // TASCA 2: Importem useTheme
import { useSpeechRecognition } from '@/composables/useSpeechRecognition';

// Composable de reconeixement de veu
const { isListening, transcript, interimTranscript, error, start } = useSpeechRecognition();

// Estat de la interfície
const uiMessage = ref("Prem el botó per començar...");
const statusColor = ref("primary");

const theme = useTheme();

const snackbar = ref(false);
const snackbarText = ref('');
const snackbarColor = ref('error');

watch(transcript, (newText) => {
  if (!newText) return;

  const command = newText.toLowerCase().trim();
  
  if (command.includes('saluda')) {
    uiMessage.value = "Hola! Benvingut a l'aplicació.";
    statusColor.value = "success";
  } 
  else if (command.includes('ajuda')) {
    uiMessage.value = "Comandes: Saluda, Esborra, Mode fosc, Mode clar.";
    statusColor.value = "info";
  } 
  
  else if (command.includes('esborra') || command.includes('borrar')) {
    uiMessage.value = "Esperant comanda..."; // Text original
    statusColor.value = "primary";         // Color original
  }
  
  else if (command.includes('mode fosc')) {
    theme.global.name.value = 'dark'; // Canvia a fosc
    uiMessage.value = "Tema fosc activat 🌙";
    statusColor.value = "grey-darken-3"; // Un color fosc per la targeta
  }
  else if (command.includes('mode clar')) {
    theme.global.name.value = 'light'; // Canvia a clar
    uiMessage.value = "Tema clar activat ☀️";
    statusColor.value = "primary";
  }
  
  // --- TASCA 3: Feedback Visual (Error) ---
  else {
    uiMessage.value = `No he entès: "${newText}"`;
    statusColor.value = "warning";
    
    // Configurem i mostrem el Snackbar
    snackbarText.value = `Comanda no reconeguda: "${newText}"`;
    snackbarColor.value = 'error'; // Color vermell
    snackbar.value = true;         // Fem visible l'avís
  }
});
</script>

<template>
  <v-container class="d-flex justify-center align-center fill-height">
    
    <v-card width="400" :color="statusColor" variant="tonal">
      <v-card-item>
        <v-card-title class="text-h5 text-center">Control per Veu</v-card-title>
      </v-card-item>

      <v-card-text class="text-center py-4">
        <div class="mb-4">
          <v-icon 
            :icon="isListening ? 'mdi-microphone' : 'mdi-microphone-off'" 
            size="64"
            :class="{'text-red animate-pulse': isListening}"
          ></v-icon>
        </div>
        
        <p class="text-h6 font-weight-bold">
          {{ isListening ? 'Escoltant...' : 'En espera' }}
        </p>
        
        <p v-if="interimTranscript" class="text-caption text-grey">
            Detectant: {{ interimTranscript }}
        </p>
        
        <p class="mt-4 text-body-1">{{ uiMessage }}</p>
        
        <v-alert v-if="error" type="error" class="mt-3" density="compact">
          {{ error }} <br>
          <small>(Prova amb Google Chrome)</small>
        </v-alert>
      </v-card-text>

      <v-card-actions class="justify-center pb-4">
        <v-btn 
          variant="elevated" 
          color="primary" 
          size="large"
          @click="start" 
          :disabled="isListening"
        >
          {{ isListening ? 'Parlant...' : 'Escolta' }}
        </v-btn>
      </v-card-actions>
    </v-card>

    <v-snackbar
      v-model="snackbar"
      :timeout="3000"
      :color="snackbarColor"
      location="bottom"
    >
      {{ snackbarText }}
      
      <template v-slot:actions>
        <v-btn
          color="white"
          variant="text"
          @click="snackbar = false"
        >
          Tanca
        </v-btn>
      </template>
    </v-snackbar>

  </v-container>
</template>

<style scoped>
.animate-pulse {
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(1.1); }
  100% { opacity: 1; transform: scale(1); }
}
</style>